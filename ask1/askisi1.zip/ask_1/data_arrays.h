string get_random_name();
string get_random_phrase();
string get_random_title();
