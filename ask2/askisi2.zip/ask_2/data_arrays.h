const string get_random_name();
const string get_random_phrase();
const string get_random_title();
